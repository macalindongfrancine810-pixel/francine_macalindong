
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
import { product as productController } from "../controllers/productController.js";
import { customer as customerController } from "../controllers/customerController.js";
import { categories as categoriesController } from "../controllers/categoriesController.js";
import { suppliers as suppliersController } from "../controllers/suppliersController.js";
import { orders as ordersController } from "../controllers/ordersController.js";
router.get("/", homePage);


router.post("/api/products", productController.insert);
router.get("/api/products", productController.selectAll);
router.get("/api/products/:id", productController.selectById);

router.post("/api/customers", customerController.insert);
router.get("/api/customers", customerController.selectAll);
router.get("/api/customers/:id", customerController.selectById);


router.post("/api/categories", categoriesController.insert);
router.get("/api/categories", categoriesController.selectAll);
router.get("/api/categories/:id", categoriesController.selectById);


router.post("/api/suppliers", suppliersController.insert);
router.get("/api/suppliers", suppliersController.selectAll);
router.get("/api/suppliers/:id", suppliersController.selectById);


router.post("/api/orders", ordersController.insert);
router.get("/api/orders", ordersController.selectAll);
router.get("/api/orders/:id", ordersController.selectById);


export default router;


